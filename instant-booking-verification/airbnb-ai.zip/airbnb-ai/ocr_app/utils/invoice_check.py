


def info_matching():
    import pymongo
    client = pymongo.MongoClient("mongodb+srv://ipsita:Ipsita%402023@uk-bd0.u3pngqk.mongodb.net/")
    db = client["airbnb"]







    
    collection = db["payments"]
    query = {"nid": 150369974}
    result = collection.find(query)

    data = []
    for doc in result:
        data.append(doc)

    print(data)

    return r'okay'


# import pymongo
# client = pymongo.MongoClient("mongodb+srv://ipsita:Ipsita%402023@uk-bd0.u3pngqk.mongodb.net/")
# db = client["airbnb"]
# collection = db["invoices"]
# query = {"nid": 150369974}
# result = collection.find(query)

# data = []
# for doc in result:
#     data.append(doc)

#print(data)
