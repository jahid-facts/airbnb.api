from flask import Flask
from pathlib import Path

import pytesseract
#from pdf2image import convert_from_path
from PIL import Image

import re
import io
import time
import os


# CONFIGARATIONS


# get the current working directory
current_working_directory = Path.cwd()
print(current_working_directory)

extract_texts_file = "output\output_of_scanned_pdf_to_text.txt"
searched_file = "output\searched_to_text.txt"
searched_lines=[]










app = Flask(__name__, 
template_folder='../templates',
static_folder='../static')

from ocr_app import routes