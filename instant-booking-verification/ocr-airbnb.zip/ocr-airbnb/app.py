

from ocr_app import app

import os

port = int(os.environ.get("PORT", 7050)) 

if __name__ == '__main__':
   
   app.run(debug=True, port=port, host='0.0.0.0')

# from flask import Flask
# from flask_cors import CORS

# app = Flask(__name__)
# CORS(app)

# port = int(os.environ.get("PORT", 7050)) 

# if __name__ == '__main__':
#     app.run(debug=True, port=port, host='0.0.0.0')