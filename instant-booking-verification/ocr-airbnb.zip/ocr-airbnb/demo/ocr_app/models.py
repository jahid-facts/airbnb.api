from django.db import models

# Create your models here.

class Person(models.Model):
    nid = models.CharField(max_length=70, blank=False, default='')
    name = models.CharField(max_length=200,blank=False, default='')
    date_of_birth = models.DateField(default=False)

class invoices(models.Model):
    nid = models.CharField(max_length=70, blank=False, default='')
    name = models.CharField(max_length=200,blank=False, default='')
