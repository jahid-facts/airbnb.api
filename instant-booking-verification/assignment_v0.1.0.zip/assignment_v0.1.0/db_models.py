'''booking object '''


#collection name booking

booking = {
    "renter_id":"",
    "property_id":"",
    "check_in_date":"",
    "check_out_date":"",
    "price":"",
    "payment_id":"",
    "cancelation_id":"",
    "review_id":""
}

