from flask import Flask, jsonify, request
from pymongo import MongoClient
from bson import ObjectId
import json
import os
from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
from dotenv import load_dotenv
from flask_cors import CORS

load_dotenv()

COSMOSDB_CONN = os.getenv('MONGODB_URI')
db_name = os.getenv('DBNAME')

app = Flask(__name__)
app.config["MONGO_URI"] = COSMOSDB_CONN
mongo = PyMongo(app)
CORS(app)


if mongo:
    #print(mongo.db.users)
    print("connected")

from routes import * 




if __name__ == "__main__":
    
    app.run(debug=True,host='0.0.0.0')

